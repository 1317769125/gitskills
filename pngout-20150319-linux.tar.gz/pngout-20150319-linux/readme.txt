PNGOUT by Ken Silverman (http://advsys.net/ken)
Linux and BSD ports by Jonathon Fowler (http://www.jonof.id.au/pngout)
Mac OS X port by Ken Silverman, with assistance by Jonathon Fowler

19 March 2015 Release
